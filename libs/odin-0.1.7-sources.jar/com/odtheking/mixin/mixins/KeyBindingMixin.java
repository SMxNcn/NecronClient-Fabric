package com.odtheking.mixin.mixins;

import com.odtheking.odin.events.InputEvent;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_304.class)
public class KeyBindingMixin {

    @Inject(method = "click", at = @At("HEAD"), cancellable = true)
    private static void onKeyPressed(class_3675.class_306 key, CallbackInfo ci) {
        if (new InputEvent(key).postAndCatch()) ci.cancel();
    }
}