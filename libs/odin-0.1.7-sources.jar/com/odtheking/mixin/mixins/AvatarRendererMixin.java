package com.odtheking.mixin.mixins;

import com.odtheking.odin.features.impl.render.PlayerSize;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11890;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public class AvatarRendererMixin {

    @Inject(method = "scale(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;)V", at = @At("HEAD"))
    private void scale(class_10055 avatarRenderState, class_4587 poseStack, CallbackInfo ci) {
        PlayerSize.preRenderCallbackScaleHook(avatarRenderState, poseStack);
    }

    @Inject(
            method = "extractRenderState(Lnet/minecraft/world/entity/Avatar;Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;F)V",
            at = @At("HEAD")
    )
    private void extractRenderState(class_11890 avatar, class_10055 avatarRenderState, float f, CallbackInfo ci) {
        if (!(avatar instanceof class_742 clientAvatarEntity)) return;
        avatarRenderState.setData(PlayerSize.getGAME_PROFILE_KEY(), clientAvatarEntity.method_7334());
    }
}