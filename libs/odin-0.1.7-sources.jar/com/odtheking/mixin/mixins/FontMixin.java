package com.odtheking.mixin.mixins;

import com.odtheking.odin.features.impl.render.CustomNameReplacer;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_327.class)
public class FontMixin {

    @ModifyVariable(method = "prepareText(Ljava/lang/String;FFIZI)Lnet/minecraft/client/gui/Font$PreparedText;", at = @At("HEAD"), argsOnly = true)
    private String onPrepareTextString(String text) {
        if (!CustomNameReplacer.isEnabled()) return text;
        return CustomNameReplacer.replaceStringIfNeeded(text);
    }

    @ModifyVariable(method = "prepareText(Lnet/minecraft/util/FormattedCharSequence;FFIZI)Lnet/minecraft/client/gui/Font$PreparedText;", at = @At("HEAD"), argsOnly = true)
    private class_5481 onPrepareTextSequence(class_5481 text) {
        if (!CustomNameReplacer.isEnabled()) return text;
        return CustomNameReplacer.replaceSequenceIfNeeded(text);
    }

    @ModifyVariable(method = "width(Ljava/lang/String;)I", at = @At("HEAD"), argsOnly = true)
    private String onWidthString(String text) {
        if (!CustomNameReplacer.isEnabled()) return text;
        return CustomNameReplacer.replaceStringIfNeeded(text);
    }

    @ModifyVariable(method = "width(Lnet/minecraft/network/chat/FormattedText;)I", at = @At("HEAD"), argsOnly = true)
    private class_5348 onWidthFormattedText(class_5348 text) {
        if (!CustomNameReplacer.isEnabled()) return text;
        if (text instanceof class_2561 component) {
            class_2561 replaced = CustomNameReplacer.replaceComponentIfNeeded(component);
            if (replaced != null) return replaced;
        }
        return text;
    }

    @ModifyVariable(method = "width(Lnet/minecraft/util/FormattedCharSequence;)I", at = @At("HEAD"), argsOnly = true)
    private class_5481 onWidthSequence(class_5481 text) {
        if (!CustomNameReplacer.isEnabled()) return text;
        return CustomNameReplacer.replaceSequenceIfNeeded(text);
    }
}