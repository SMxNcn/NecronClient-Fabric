package com.odtheking.mixin.mixins;

import com.odtheking.odin.features.impl.skyblock.PlayerDisplay;
import net.minecraft.class_2561;
import net.minecraft.class_7594;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(class_7594.class)
public class ChatListenerMixin {

    @ModifyArg(method = "handleSystemMessage", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;setOverlayMessage(Lnet/minecraft/network/chat/Component;Z)V"), index = 0)
    private class_2561 modifyOverlayMessage(class_2561 component) {
        return PlayerDisplay.modifyText(component);
    }
}
