package com.odtheking.mixin.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.odtheking.odin.events.GuiEvent;
import com.odtheking.odin.events.PacketEvent;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import net.minecraft.class_2653;
import net.minecraft.class_465;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static com.odtheking.odin.OdinMod.getMc;

@Mixin(class_634.class)
public class ClientPacketListenerMixin {

    @ModifyExpressionValue(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/DebugScreenOverlay;showNetworkCharts()Z"))
    private boolean alwaysSendPing(boolean original) {
        return true;
    }

    @Inject(method = "handleContainerSetSlot", at = @At("TAIL"))
    private void onSetSlot(class_2653 clientboundContainerSetSlotPacket, CallbackInfo ci) {
        if (getMc().screen instanceof class_465<?> container)
            new GuiEvent.SlotUpdate(getMc().screen, clientboundContainerSetSlotPacket, container.method_17577()).postAndCatch();
    }

    @WrapOperation(method = "handleBundlePacket", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/protocol/Packet;handle(Lnet/minecraft/network/PacketListener;)V"))
    private void wrapPacketHandle(class_2596<?> packet, class_2547 listener, Operation<Void> original) {
        if (new PacketEvent.Receive(packet).postAndCatch()) return;
        original.call(packet, listener);
    }
}