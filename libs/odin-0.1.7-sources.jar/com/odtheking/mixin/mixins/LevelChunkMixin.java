package com.odtheking.mixin.mixins;

import com.odtheking.odin.events.BlockUpdateEvent;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2818.class)
public abstract class LevelChunkMixin {
    @Shadow
    public abstract class_2680 getBlockState(class_2338 pos);

    @Inject(method = "setBlockState", at = @At("HEAD"))
    private void onBlockChange(class_2338 pos, class_2680 state, int flags, CallbackInfoReturnable<class_2680> cir) {
        class_2680 old = this.getBlockState(pos);
        if (old != state) (new BlockUpdateEvent(pos, old, state)).postAndCatch();
    }
}