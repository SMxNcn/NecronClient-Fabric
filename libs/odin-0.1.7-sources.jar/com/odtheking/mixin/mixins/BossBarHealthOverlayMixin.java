package com.odtheking.mixin.mixins;

import com.odtheking.odin.events.RenderBossBarEvent;
import net.minecraft.class_1259;
import net.minecraft.class_332;
import net.minecraft.class_337;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_337.class)
public abstract class BossBarHealthOverlayMixin {

    @Inject(method = "drawBar(Lnet/minecraft/client/gui/GuiGraphics;IILnet/minecraft/world/BossEvent;)V", at = @At("HEAD"), cancellable = true)
    private void onRenderBossBar(class_332 guiGraphics, int i, int j, class_1259 bossEvent, CallbackInfo ci) {
        if (new RenderBossBarEvent(bossEvent).postAndCatch()) ci.cancel();
    }
}