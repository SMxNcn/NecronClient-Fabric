package com.odtheking.mixin.mixins;

import com.odtheking.odin.features.impl.render.HidePlayers;
import com.odtheking.odin.features.impl.render.RenderOptimizer;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_4604;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_897.class)
public abstract class EntityRendererMixin<T extends class_1297> {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void onRender(T entity, class_4604 frustum, double d, double e, double f, CallbackInfoReturnable<Boolean> cir) {
        if (!HidePlayers.shouldRenderPlayer(entity)) cir.setReturnValue(false);

        if (RenderOptimizer.hideEntityDeathAnimation() && entity instanceof class_1309 livingEntity && livingEntity.method_29504())
            cir.setReturnValue(false);

        if (RenderOptimizer.hideDyingEntityArmorStand() && entity instanceof class_1531 armorStand) {
            class_1297 self = armorStand.method_73183().method_8469(armorStand.method_5628() - 1);
            if (self instanceof class_1309 livingEntity && livingEntity.method_29504()) cir.setReturnValue(false);
        }
    }
}

