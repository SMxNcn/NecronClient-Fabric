package com.odtheking.mixin.accessors;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_1921;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1921.class_4687.class)
public interface CompositeRenderTypeAccessor {
    @Accessor("renderPipeline")
    RenderPipeline getRenderPipeline();
}
