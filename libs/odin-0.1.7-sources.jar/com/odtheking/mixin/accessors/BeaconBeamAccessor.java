package com.odtheking.mixin.accessors;

import net.minecraft.class_11659;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_822;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_822.class)
public interface BeaconBeamAccessor {
    @Invoker("submitBeaconBeam")
    static void invokeRenderBeam(
            class_4587 matrices, class_11659 queue, class_2960 textureId, float beamHeight, float beamRotationDegrees, int minHeight, int maxHeight, int color, float innerScale, float outerScale
    ) {
        throw new UnsupportedOperationException();
    }
}
